// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'parts.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PartsImpl _$$PartsImplFromJson(Map<String, dynamic> json) => _$PartsImpl(
      text: json['text'] as String?,
    );

Map<String, dynamic> _$$PartsImplToJson(_$PartsImpl instance) =>
    <String, dynamic>{
      'text': instance.text,
    };
