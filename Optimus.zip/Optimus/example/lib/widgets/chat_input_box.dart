import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class ChatInputBox extends StatefulWidget {
  final TextEditingController? controller;
  final VoidCallback? onSend, onClickCamera;
  final void Function(String) onVoiceSend; // New callback for sending voice input

  ChatInputBox({
    Key? key,
    this.controller,
    this.onSend,
    this.onClickCamera,
    required this.onVoiceSend,

  }) : super(key: key);

  @override
  _ChatInputBoxState createState() => _ChatInputBoxState();
}

class _ChatInputBoxState extends State<ChatInputBox> {

  bool _isListening = false;
  String text='';
  final stt.SpeechToText speech = stt.SpeechToText();

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (widget.onClickCamera != null)
            Padding(
              padding: const EdgeInsets.all(4.0),
              child: IconButton(
                onPressed: widget.onClickCamera,
                color: Theme.of(context).colorScheme.onSecondary,
                icon: const Icon(
                  Icons.photo_camera_front,
                  size: 30.0,
                  color: Colors.white,
                ),
              ),
            ),
          Expanded(
            child: TextField(
              controller: widget.controller,
              minLines: 1,
              maxLines: 4,
              cursorColor: Colors.black,
              textInputAction: TextInputAction.newline,
              keyboardType: TextInputType.multiline,
              decoration: const InputDecoration(
                contentPadding:
                EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                hintText: 'Ask me anything',
                border: InputBorder.none,
              ),
              onTapOutside: (event) =>
                  FocusManager.instance.primaryFocus?.unfocus(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(4.0),
            child: Row(
              children: [
                FloatingActionButton.small(
                  onPressed: widget.onSend,
                  child: const Icon(
                    Icons.send,
                    color: Colors.black,
                    size: 25.0,
                  ),
                ),
                IconButton(
                  onPressed: _isListening ? _stopListening :_listen,
                  icon: Icon(
                    Icons.mic,
                    color: _isListening ? Colors.red : Colors.white,
                    size: 25.0,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  void _listen() async {
    if (!_isListening) {
      bool available = await speech.initialize(
        onStatus: (val) => print('onStatus: $val'),
        onError: (val) => print('onError: $val'),
      );
      if (available) {
        setState(() => _isListening = true);
        speech.listen(
          onResult: (val) => setState(() {
            text = val.recognizedWords;

            print(text);
          }

          ),
        );
      }
    }
  }
  void _stopListening() {
    setState(() => _isListening = false);
    speech.stop();// Speak the recognized text
    widget.onVoiceSend(text); // Pass the recognized text to the callback function
  }
}




