class OnboardContents {
  final String lottie;
  final String title;
  final String subtitle;

  OnboardContents({ required this.lottie, required this.title, required this.subtitle});

}

final contentList =  [
  //screen 1 content
  OnboardContents(
    lottie: 'screen1',// image name in assets/onboard folder
    title: 'Welcome on Board',
    subtitle: 'I\'m a AI Powered App,'
      'I can be your friend & You can ask me anything & I will help you',
      ),
  //screen 2 content // we can add any no of contents
  OnboardContents(
    lottie: 'screen5',
    title: 'What you can do here?',
    subtitle: 'Our App has limited number of AI features!,'
        ' Choose the features you want to use.'
        'Go to next page to continue.'
    ,
  ),
  OnboardContents(
    lottie: 'screen4',
    title: 'Imagination to Reality!',
    subtitle: 'Just imagine anything & let me know,'
        ' I will create something wonder full for you!'
        ' Click on "Get Started" to continue to our app!',
  ),

];