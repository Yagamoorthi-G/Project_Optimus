import 'dart:typed_data';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:optimus/sections/constants.dart';
import 'package:optimus/widgets/chat_input_box.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gemini/flutter_gemini.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lottie/lottie.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
class SectionTextAndImageInput extends StatefulWidget {

  static const String id = 'imagetotext';

  const SectionTextAndImageInput({Key? key}) : super(key: key);
  @override
  State<SectionTextAndImageInput> createState() =>
      _SectionTextAndImageInputState();
}
final tts = FlutterTts();

class _SectionTextAndImageInputState extends State<SectionTextAndImageInput> {
  final ImagePicker picker = ImagePicker();
  final controller = TextEditingController();
  final gemini = Gemini.instance;
  String? searchedText, result;
  bool _loading = false;
  final stt.SpeechToText speech = stt.SpeechToText();
  Uint8List? selectedImage;
  bool get loading => _loading;
  set loading(bool set) => setState(() => _loading = set);


  void receiveVoiceInput(String voiceInput) {
    _handleVoiceInput(voiceInput);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xFF191C47),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,

          children:[
            Lottie.asset('assets/lottie/logo.json',height: 70),
            Text(
              'Image to Text',
              style: TextStyle(
                color: Colors.white,
                fontSize: 30.0,
                fontWeight: FontWeight.bold,
                fontFamily: GoogleFonts.poppins().fontFamily,
              ),
            ).animate(onPlay: (controller) => controller.repeat(reverse: true))
                .tint()
                .shimmer(duration: 2000.milliseconds, color: Colors.white),
          ],
        ),

      ),
      body: Column(
        children: [
          if (searchedText != null)
            MaterialButton(
                color: mainbg2,
                onPressed: () {
                  setState(() {
                    searchedText = null;
                    result = null;
                  });
                },
                child: Text('You Searched: $searchedText')),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    flex: 2,
                    child: loading
                        ? Lottie.asset('assets/lottie/ai3.json')
                        : result != null
                        ? Markdown(
                      data: result!,
                      padding:
                      const EdgeInsets.symmetric(horizontal: 12),
                    )
                        : const Center(
                      child: Text(
                        'Add an Image and Type something!',
                        style: TextStyle(
                            color: Colors.white, fontSize: 20.0),
                      ),
                    ),
                  ),
                  if (selectedImage != null)
                    Expanded(
                      flex: 1,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(32),
                        child: Image.memory(
                          selectedImage!,
                          fit: BoxFit.cover,
                        ),
                      ),
                    )
                ],
              ),
            ),
          ),
          ChatInputBox(
            controller: controller,
            onClickCamera: () async {
              final XFile? photo =
              await picker.pickImage(source: ImageSource.camera);
      
              if (photo != null) {
                photo.readAsBytes().then((value) => setState(() {
                  selectedImage = value;
                }));
              }
            },
            onSend: () {
              _handleText(controller.text);
      
            },
            onVoiceSend: receiveVoiceInput,
          ),
        ],
      ),
    );
  }
  Future<void> _speak(String text) async {
    await tts.setLanguage('en-US');
    await tts.setPitch(1);
    await tts.setSpeechRate(0.5);
    await tts.speak(text);
  }
  void _handleText(String text){
    if (text.isNotEmpty && selectedImage != null) {
      searchedText = controller.text;
      controller.clear();
      loading = true;

      gemini.textAndImage(
          text: searchedText!, images: [selectedImage!]).then((value) {
        result = value?.content?.parts?.last.text;
        loading = false;
        if (result != null) {
          _speak(result!);
        }
      });
    }
  }
  void _handleVoiceInput(String text) {
    searchedText = text;
    controller.clear();
    loading = true;

    gemini.textAndImage(
        text: searchedText!, images: [selectedImage!]).then((value) {
      result = value?.content?.parts?.last.text;
      loading = false;
      if (result != null) {
        _speak(result!);
      }
    });
  }


  @override
  void dispose() {
    super.dispose();
    tts.stop();
    speech.stop();
  }
}



