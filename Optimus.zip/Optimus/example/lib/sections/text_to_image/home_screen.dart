import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:optimus/sections/constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'rest.dart';

class HomePage extends StatefulWidget {

  static const String id = 'texttoimage';

  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final textController = TextEditingController();

  bool isLoading = false;

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xFF191C47),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children:[
            Lottie.asset('assets/lottie/logo.json',height: 70),
            Text(
              'Text to Image',
              style: TextStyle(
                color: Colors.white,
                fontSize: 30.0,
                fontWeight: FontWeight.bold,
                fontFamily: GoogleFonts.poppins().fontFamily,
              ),
            ).animate(onPlay: (controller) => controller.repeat(reverse: true))
                .tint()
                .shimmer(duration: 2000.milliseconds, color: Colors.white),
          ],
        ),

      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.symmetric(vertical: 80.0), // Adding margin
              child: const  Text(
                'Search Something!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
            const SizedBox(height: 0), // Adding some space between Text and TextField
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 50.0, bottom: 0.0),
                child: TextField(
                  controller: textController,
                  cursorColor: Colors.white,
                  decoration: InputDecoration(
                    hintText: 'eg: a monkey on plane',
                    fillColor: mainbg,
                    filled: true,
                    contentPadding: const EdgeInsets.all(20),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              width: 180,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: mainbg,
                ),
                onPressed: () {
                  convertTextToImage(textController.text, context);
                  isLoading = true;
                  setState(() {});
                },
                child: isLoading
                    ? const SizedBox(
                  height: 5,
                  width: 25,
                  child: CircularProgressIndicator(color: Colors.white,),
                )
                    :  Text('Generate Image',
                    style: TextStyle(color: Colors.white,
                    fontSize: 15,
                    fontFamily: GoogleFonts.poppins().fontFamily,),),
              ),
              ),
           ],
        ),
      ),
    ),
  );
}
