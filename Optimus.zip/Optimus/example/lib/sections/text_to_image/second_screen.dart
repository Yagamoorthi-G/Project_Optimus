import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class SecondScreen extends StatefulWidget {
  final Uint8List image;
   const SecondScreen({super.key, required this.image});

  @override
  State<SecondScreen> createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink[800],
        centerTitle: true,
        title: Text(
          'Generated AI IMAGE',
          style: TextStyle(
              fontFamily: GoogleFonts.poppins().fontFamily,
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 35.0),
        ),
      ),
      //backgroundColor: Colors.pink[800],
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
            children: [
          const SizedBox(
            height: 50,
          ),
          Container( //width and height of image
            width: 330,
            height: 450,
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(25),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(25),
              child: Image.memory(
                widget.image,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(
            height: 50,
          ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: RoundedContainerWithIcon(
                      icon: Icons.arrow_back,
                    ),
                  ),
                  RoundedContainerWithIcon(
                    icon: Icons.download_for_offline_sharp,
                  ),
                ],
              )

            ]),
      ),
    );
  }
}

class RoundedContainerWithIcon extends StatelessWidget {
  final IconData icon;

  const RoundedContainerWithIcon({super.key, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: Colors.pink[600],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Icon(
          icon,
          size: 30,
          color: Colors.white, // Change the icon color as needed
        ),
      ),
    );
  }
}