import 'dart:typed_data';
import 'package:optimus/sections/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_gemini/flutter_gemini.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lottie/lottie.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../widgets/chat_input_box.dart';
import '../widgets/item_image_view.dart';

class SectionTextStreamInput extends StatefulWidget {

  static const String id = 'Stream';

  const SectionTextStreamInput({super.key});
  @override
  State<SectionTextStreamInput> createState() => _SectionTextStreamInputState();
}

class _SectionTextStreamInputState extends State<SectionTextStreamInput> {
  final ImagePicker picker = ImagePicker();
  final TextEditingController controller = TextEditingController();
  final gemini = Gemini.instance;
  String? searchedText, _finishReason;
  List<Uint8List>? images;
  final tts = FlutterTts();
  final stt.SpeechToText speech = stt.SpeechToText();

  String? get finishReason => _finishReason;

  set finishReason(String? set) {
    if (set != _finishReason) {
      setState(() => _finishReason = set);
    }
  }
  void receiveVoiceInput(String voiceInput) {
    _handleVoiceInput(voiceInput);
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (searchedText != null)
          MaterialButton(
            color: mainbg2,
            onPressed: () {
              setState(() {
                searchedText = null;
                finishReason = null;
              });
            },
            child: Text('You Searched: $searchedText'),
          ),
        Expanded(
          child: GeminiResponseTypeView(
            builder: (context, child, response, loading) {
              if (loading) {
                return Lottie.asset('assets/lottie/ai3.json',height: 1000);
              }
              if (response != null) {
                _speak(response);
                return Markdown(
                  data: response,
                  selectable: true,
                );
              } else {
                return const Center(
                  child: Text(
                    'Search something!',
                    style: TextStyle(color: Colors.white, fontSize: 18.0),
                  ),
                );
              }
            },
          ),
        ),
        if (finishReason != null) Text(finishReason!),
        if (images != null)
          Container(
            height: 120,
            padding: const EdgeInsets.symmetric(horizontal: 4),
            alignment: Alignment.centerLeft,
            child: Card(
              child: ListView.builder(
                itemBuilder: (context, index) => ItemImageView(
                  bytes: images!.elementAt(index),
                ),
                itemCount: images!.length,
                scrollDirection: Axis.horizontal,
              ),
            ),
          ),
        ChatInputBox(
          controller: controller,
          onClickCamera: () {
            picker.pickMultiImage().then((value) async {
              final imagesBytes = <Uint8List>[];
              for (final file in value!) {
                imagesBytes.add(await file.readAsBytes());
              }
              if (imagesBytes.isNotEmpty) {
                setState(() {
                  images = imagesBytes;
                });
              }
            });
          },
          onSend: () {
            _handleText(controller.text);
          },
          onVoiceSend: receiveVoiceInput,
        )
      ],
    );
  }


  Future<void> _speak(String text) async {
    await tts.setLanguage('en-US');
    await tts.setPitch(1);
     await tts.setSpeechRate(0.7);
    await tts.speak(text);
  }

  void _handleText(String text) {
    if (text.isNotEmpty) {
      searchedText = text;
      controller.clear();
      gemini.streamGenerateContent(searchedText!, images: images).listen((value) {
        setState(() {
          images = null;
        });

        if (value.finishReason != 'STOP') {
          finishReason = 'Finish reason is  a `RECITATION`';
          _speak(finishReason!);
        }
      }).onError((e) {
        debugPrint('streamGenerateContent error: $e');
      });
    }
  }

  void _handleVoiceInput(String text) {
    if (text.isNotEmpty) {
      searchedText = text;
      controller.clear();
      gemini.streamGenerateContent(searchedText!, images: images).listen((value) {
        setState(() {
          images = null;
        });

        if (value.finishReason != 'STOP') {
          finishReason = 'Try again';
          _speak(finishReason!);
        }
      }).onError((e) {
        debugPrint('streamGenerateContent error: $e');
      });
    }

  }

  @override
  void dispose() {
    super.dispose();
    tts.stop();
    speech.stop();
  }
}



