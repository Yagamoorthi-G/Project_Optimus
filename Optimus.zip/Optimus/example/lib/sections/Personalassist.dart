
import 'package:flutter_animate/flutter_animate.dart';
import 'package:optimus/sections/stream.dart';
import 'package:optimus/sections/text_and_image.dart';
import 'package:optimus/sections/text_only.dart';
import 'package:optimus/sections/text_to_image/home_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:optimus/sections/constants.dart';


class SectionItem {
  final int index;
  final String title;
  final Widget widget;
  SectionItem(this.index, this.title, this.widget);
}

class MyHomePage extends StatefulWidget {

  static const String id='mainpage';

  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedItem = 0;
  final _sections = <SectionItem>[
    SectionItem(0, 'Jarvis', const SectionTextStreamInput()),
    SectionItem(1, 'Image to Text', const SectionTextAndImageInput()),
    SectionItem(2, 'Text to Story', const SectionTextInput()),
    SectionItem(3, 'Text to Image', const HomePage()),

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xFF191C47),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,

          children:[
            Lottie.asset('assets/lottie/logo.json',height: 70),
            Text(
              _selectedItem == 0 ? 'Jarvis' : _sections[_selectedItem].title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 30.0,
                fontWeight: FontWeight.bold,
                fontFamily: GoogleFonts.poppins().fontFamily,
              ),
            ).animate(onPlay: (controller) => controller.repeat(reverse: true))
                .tint()
                 .shimmer(duration: 2000.milliseconds, color: Colors.white),
          ],
        ),

      ),
      body: IndexedStack(
        index: _selectedItem,
        children: _sections.map((e) => e.widget).toList(),
      ),
    );
  }
}