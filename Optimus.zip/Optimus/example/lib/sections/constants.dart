

import 'dart:ui';

import 'package:flutter/material.dart';

const Color mainFontColor = Color.fromRGBO(19, 61, 95, 1);
const Color bg1 = Color(0x228265E5);
const Color secondSuggestionBoxColor = Color(0x55434277);
const Color mainbg2 = Color(0xEE434277);
const Color Textcolor = Color.fromRGBO(209, 243, 249, 1);
const Color borderColor = Color.fromRGBO(200, 200, 200, 1);
const Color blackColor = Colors.black;
const Color whiteColor = Colors.white;
const Color mainbg = Color(0xFF191C47);


const  kTextFieldDecoration = InputDecoration(
  hintText: 'Enter your email',
  hintStyle: TextStyle(color: Colors.blueGrey),
  contentPadding:
  EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(32.0)),
  ),
  enabledBorder: OutlineInputBorder(
    borderSide:
    BorderSide(color: Colors.lightBlueAccent, width: 1.0),
    borderRadius: BorderRadius.all(Radius.circular(32.0)),
  ),
  focusedBorder: OutlineInputBorder(
    borderSide:
    BorderSide(color: Colors.lightBlueAccent, width: 2.0),
    borderRadius: BorderRadius.all(Radius.circular(32.0)),
  ),
);


const colorizeColors = [
  Colors.purple,
  Colors.blue,
  Colors.yellow,
  Colors.red,
];

const colorizeTextStyle = TextStyle(
  fontSize: 50.0,
  fontFamily: 'Horizon',
);

const homeCardTitleTextStyle = TextStyle(
    fontSize: 16.0, fontWeight: FontWeight.bold
);