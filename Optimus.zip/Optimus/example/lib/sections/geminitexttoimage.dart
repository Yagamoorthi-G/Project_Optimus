// import 'dart:html';
//
// import 'package:flutter/material.dart';
// import 'package:flutter_gemini/flutter_gemini.dart';
// import 'package:flutter_markdown/flutter_markdown.dart';
// import 'package:flutter_tts/flutter_tts.dart';
// import 'package:lottie/lottie.dart';
// import 'package:markdown/markdown.dart';
// import 'package:speech_to_text/speech_to_text.dart' as stt;
// import 'package:image_to_pdf_converter/image_to_pdf_converter.dart';
//
// import '../widgets/chat_input_box.dart';
// import 'constants.dart';
//
// class SectionTextInput extends StatefulWidget {
//   static const String id = 'texttostory';
//
//   const SectionTextInput({Key? key}) : super(key: key);
//
//   @override
//   State<SectionTextInput> createState() => _SectionTextInputState();
// }
//
// class _SectionTextInputState extends State<SectionTextInput> {
//   final controller = TextEditingController();
//   final gemini = Gemini.instance;
//   final tts = FlutterTts();
//   String? searchedText, result, imagePath;
//   bool _loading = false;
//   final stt.SpeechToText speech = stt.SpeechToText();
//
//   bool get loading => _loading;
//
//   set loading(bool set) => setState(() => _loading = set);
//
//   void receiveVoiceInput(String voiceInput) {
//     _handleVoiceInput(voiceInput);
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         if (searchedText != null)
//           MaterialButton(
//             color: mainbg2,
//             onPressed: () {
//               setState(() {
//                 searchedText = null;
//                 result = null;
//                 imagePath = null;
//               });
//             },
//             child: Text('You Searched: $searchedText'),
//           ),
//         Expanded(
//           child: loading
//               ? Lottie.asset('assets/lottie/ai3.json')
//               : result != null
//               ? Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: imagePath != null
//                 ? Image.file(File(imagePath!))
//                 : Markdown(data: result!),
//           )
//               : const Center(
//             child: Text(
//               'Give a title',
//               style: TextStyle(color: Colors.white, fontSize: 20.0),
//             ),
//           ),
//         ),
//         ChatInputBox(
//           controller: controller,
//           onSend: () {
//             if (controller.text.isNotEmpty) {
//               String storytext = "A story about ${controller.text}";
//               searchedText = storytext;
//               controller.clear();
//               loading = true;
//               gemini.text(searchedText!).then((value) {
//                 result = value?.content?.parts?.last.text;
//                 loading = false;
//                 if (result != null) {
//                   _speak(result!);
//                   _generateImage(result!);
//                 }
//               });
//             }
//           },
//           onVoiceSend: receiveVoiceInput,
//         ),
//       ],
//     );
//   }
//
//   Future<void> _speak(String text) async {
//     await tts.setLanguage('en-US');
//     await tts.setPitch(1);
//     await tts.setSpeechRate(0.7);
//     await tts.speak(text);
//   }
//
//   void _handleVoiceInput(String text) {
//     if (text.isNotEmpty) {
//       searchedText = "A story about $text";
//       controller.clear();
//       loading = true;
//       gemini.text(searchedText!).then((value) {
//         result = value?.content?.parts?.last.text;
//         loading = false;
//         if (result != null) {
//           _speak(result!);
//           _generateImage(result!);
//         }
//       });
//     }
//   }
//
//   Future<void> _generateImage(String text) async {
//     final image = await FlutterImageToPdf.convert(
//       PdfPageFormat.a4,
//       text: text,
//     );
//     setState(() {
//       imagePath = image.path;
//     });
//   }
//
//   @override
//   void dispose() {
//     super.dispose();
//     tts.stop();
//     speech.stop();
//   }
// }
