import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:translator/translator.dart';
import '../sections/constants.dart';


class TranslatorPage extends StatefulWidget {


  static const String id = 'Translator';
  const TranslatorPage({Key? key}) : super(key: key);

  @override
  State<TranslatorPage> createState() => _TranslatorPageState();
}

class _TranslatorPageState extends State<TranslatorPage> {
  List<String> languages = [
    'Tamil',
    'English',
    'Hindi',
    'Malayalam',
    'Telugu',
  ];
  List<String> languageCode = [
    'ta',
    'en',
    'hi',
    'ml',
    'te',
  ];
  final translator = GoogleTranslator();
  String from = 'en';
  String to = 'ta';
  String data = 'நீங்க எப்படி இருக்கீங்க?';
  String selectedValue = 'English';
  String selectedValue2 = 'Tamil';
  final formKey = GlobalKey<FormState>();
  bool isloading = false;

  TextEditingController controller = TextEditingController(text: 'How are you?');

  translate() async {
    try {
      if (formKey.currentState!.validate()) {
        setState(() {
          isloading = true;
        });
        await translator.translate(controller.text, from: from, to: to).then((value) {
          setState(() {
            data = value.text;
            isloading = false;
          });
        });
      }
    } on SocketException catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please Connect to Internet'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 4),
        ),
      );
      setState(() {
        isloading = false;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xFF191C47),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,

          children:[
            Lottie.asset('assets/lottie/logo.json',height: 70),
            Text(
              'Translator',
              style: TextStyle(
                color: Colors.white,
                fontSize: 30.0,
                fontWeight: FontWeight.bold,
                fontFamily: GoogleFonts.poppins().fontFamily,
              ),
            )..animate(onPlay: (controller) => controller.repeat(reverse: true))
                .tint()
                .shimmer(duration: 2000.milliseconds, color: Colors.white),
          ],
        ),

      ),
      // appBar: AppBar(
      //   automaticallyImplyLeading: true,
      //   elevation: 19.0,
      //   title:  Text(
      //     'Translator',
      //     textAlign: TextAlign.left,
      //       style: TextStyle(
      //       fontSize: 30.0,
      //       fontWeight: FontWeight.bold,
      //       fontFamily: GoogleFonts.poppins().fontFamily,
      //     ),
      //   ) .animate(onPlay: (controller) => controller.repeat(reverse: true))
      //       .tint()
      //       .shimmer(duration: 2000.milliseconds, color: Colors.white),
      // ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 16.0),
    //---------------- 'FROM' AND LANGUAGE SELCTION--------------------------
            Container(
              height: 60.0,
              margin: const EdgeInsets.symmetric(horizontal: 40.0),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('From', style: TextStyle(color: Colors.white),),
                  const SizedBox(width: 50.0),
                  DropdownButton(
                    value: selectedValue,
                    items: languages.map((lang) {
                      return DropdownMenuItem(
                        onTap: () {
                          setState(() {
                            selectedValue = lang;
                            from = languageCode[languages.indexOf(lang)];
                          });
                        },
                        value: lang,
                        child: Text(lang,),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedValue = value.toString();
                        from = languageCode[languages.indexOf(selectedValue)];
                      });
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16.0),
    //-----------------USER ENTER TEXTFIELD-------------------------------
            Container(
              padding: const EdgeInsets.all(10.0),
              margin: const EdgeInsets.all(12.0),
              decoration: BoxDecoration(
                color: mainbg2,
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Form(
                key: formKey,
                child: TextFormField(
                  controller: controller,
                  maxLines: null,
                  minLines: 3,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter the Text';
                    }
                    return null;
                  },
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    errorStyle: TextStyle(color: Colors.black),
                  ),
                  style: const TextStyle(
                    //color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16.0),
    //---------------- 'TO' AND LANGUAGE SELECTION--------------------------
            Container(
              height: 60.0,
              margin: const EdgeInsets.symmetric(horizontal: 40.0),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('To', style: TextStyle(color: Colors.white),),
                  const SizedBox(width: 50.0),
                  DropdownButton(
                    value: selectedValue2,
                    items: languages.map((lang) {
                      return DropdownMenuItem(
                        onTap: () {
                          setState(() {
                            selectedValue2 = lang;
                            to = languageCode[languages.indexOf(lang)];
                          });
                        },
                        value: lang,
                        child: Text(lang),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedValue2 = value.toString();
                        to = languageCode[languages.indexOf(selectedValue2)];
                      });
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16.0),
    //-------------------------OUTPUT TEXT--------------------------------
            Container(
              height: 120.0,
              padding: const EdgeInsets.all(10.0),
              margin: const EdgeInsets.all(12.0),
              decoration: BoxDecoration(
                color: mainbg2,
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Center(
                child: SelectableText(
                  data,
                  style: const TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24.0),
    //----------------------BUTTON------------------------------------------------
            ElevatedButton(
              onPressed: translate,
              style: ElevatedButton.styleFrom(
                backgroundColor: mainbg2,
                foregroundColor: Colors.white,
                elevation: 1.0,
                minimumSize: const Size(175, 50),

              ),
              child: isloading ? const CircularProgressIndicator() : const Text('Translate'),
            ),
          ],
        ),
      ),
    );
  }
}

