import 'package:optimus/HomePage/home_screen.dart';
import 'package:optimus/intro/Credentials/Failed.dart';
import 'package:optimus/intro/Credentials/Login.dart';
import 'package:optimus/intro/Credentials/SignUp.dart';
import 'package:optimus/intro/Credentials/Welcome.dart';
import 'package:optimus/intro/Credentials/phone.dart';
import 'package:optimus/intro/Credentials/verify.dart';
import 'package:optimus/intro/Opening/ExistUser.dart';
import 'package:optimus/language_translator/translator.dart';
import 'package:optimus/onBoardingScreen/onboarding_screen.dart';
import 'package:optimus/sections/Personalassist.dart';
import 'package:optimus/sections/stream.dart';
import 'package:optimus/sections/text_and_image.dart';
import 'package:optimus/sections/text_only.dart';
import 'package:optimus/sections/text_to_image/home_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gemini/flutter_gemini.dart';
import 'intro/Opening/OpenPage.dart';
import 'dart:io';

void main() async{
  Gemini.init(apiKey: '', enableDebugging: true);
  WidgetsFlutterBinding.ensureInitialized();
  Platform.isAndroid ? await Firebase.initializeApp(
      options: const FirebaseOptions(apiKey:'',
          appId: '',
          messagingSenderId: '', projectId: '')

  ):await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(),
      //debugShowCheckedModeBanner: false,
      darkTheme: ThemeData.dark(
        useMaterial3: true,
      ).copyWith(
          colorScheme: ColorScheme.fromSeed(seedColor: Color(0xEE434277)),
          cardTheme: CardTheme(color: Color(0xFF191C47))
      ),
    initialRoute: OpenPage.id,
    routes:{
        WelcomeScreen.id:(context) => WelcomeScreen(),
      LoginScreen.id:(context) => LoginScreen(),
      SignUp.id:(context) => SignUp(),
      OpenPage.id:(context) => OpenPage(),
      MyHomePage.id:(context) => MyHomePage(),
      FailedPage.id:(context) => FailedPage(),
      ExistUser.id:(context) => ExistUser(),
      TranslatorPage.id:(context) => TranslatorPage(),
      OnBoardingScreen.id:(context) => OnBoardingScreen(),
      HomeScreen.id:(context) => HomeScreen(),
      SectionTextStreamInput.id:(context) => SectionTextStreamInput(),
      SectionTextAndImageInput.id:(context) => SectionTextAndImageInput(),
      SectionTextInput.id:(context) => SectionTextInput(),
      HomePage.id:(context) => HomePage(),
      MyPhone.id:(context) => MyPhone(),
      MyVerify.id:(context) => MyVerify(verificationId: '',),



    }


    );
  }
}


