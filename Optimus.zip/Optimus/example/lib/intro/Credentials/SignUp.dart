import 'package:optimus/intro/Credentials/phone.dart';
import 'package:optimus/intro/Opening/ExistUser.dart';
import 'package:optimus/onBoardingScreen/onboarding_screen.dart';
import 'package:optimus/sections/Personalassist.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../sections/constants.dart';
import 'Failed.dart';
import 'RoundedButton.dart';
import 'google_auth.dart';

class SignUp extends StatefulWidget {

  static const String id='signup';

  @override
  _SignUpState createState() => _SignUpState();
}
final _auth = FirebaseAuth.instance;
late String email;
late String password;

class _SignUpState extends State<SignUp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: mainbg,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                height: 200.0,
                //child: Image.asset('images/logo.png'),
              ),
              SizedBox(
                height: 48.0,
              ),
              TextField(
                keyboardType: TextInputType.emailAddress,
                textAlign: TextAlign.center,
                onChanged: (value) {
                  email = value;
                },
                decoration: kTextFieldDecoration.copyWith(hintText: 'Enter your Email'),
              ),
              SizedBox(
                height: 8.0,
              ),
              TextField(
                keyboardType: TextInputType.emailAddress,
                textAlign: TextAlign.center,
                obscureText: true,
                onChanged: (value) {
                  password = value;
                },
                decoration:kTextFieldDecoration.copyWith(hintText: 'Enter your Password'),
              ),
              SizedBox(
                height: 24.0,
              ),
              RoundedButton(color: borderColor, btntitle: 'SignUp', onpressed: () async {
                try {
                  final newUser = await _auth.createUserWithEmailAndPassword(
                      email: email, password: password);
                  if(newUser != null)
                    {
                      Navigator.pushNamed(context, OnBoardingScreen.id);
                    }
                  else
                    {
                      Navigator.pushNamed(context, FailedPage.id);
                    }
                }
                catch(e)
                {
                  print(e);
                  Navigator.pushNamed(context, FailedPage.id);
                }
              }, txtcolor: mainbg,),
              SizedBox(
                height: 30,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
        
                    child: TextButton(
                        onPressed: () async {
                          bool success = await AuthService().signInWithGoogle();
                          if (success) {
                            Navigator.pushNamed(context, OnBoardingScreen.id);
                          } else {
                            Navigator.pushNamed(context, FailedPage.id);
                          }
                        },
                        child: Image.asset('assets/lottie/googlelogo.jpg',height: 40,)),
                  ),
                  SizedBox(
                    width: 70,
                  ),
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
        
                    child: TextButton(onPressed: (){

                      Navigator.pushNamed(context, MyPhone.id);

        
                    }, child: Image.asset('assets/lottie/phonelogo.png',height: 40,)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

  }

}