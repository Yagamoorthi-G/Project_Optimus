import 'package:optimus/intro/Credentials/Failed.dart';
import 'package:optimus/intro/Credentials/RoundedButton.dart';
import 'package:optimus/intro/Credentials/google_auth.dart';
import 'package:optimus/intro/Credentials/phone.dart';
import 'package:optimus/intro/Opening/ExistUser.dart';
import 'package:optimus/sections/constants.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../sections/Personalassist.dart';

class LoginScreen extends StatefulWidget {

  static const String id='login';

  @override
  _LoginScreenState createState() => _LoginScreenState();
}
final _auth = FirebaseAuth.instance;
late String email;
late String password;

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: mainbg,
      body:
      SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                height: 200.0,
                //child: Image.asset('images/logo.png'),
              ),
              SizedBox(
                height: 48.0,
              ),
              TextField(
                keyboardType: TextInputType.emailAddress,
                textAlign: TextAlign.center,
                onChanged: (value) {
        
                  email = value;
                },
                decoration: kTextFieldDecoration.copyWith(hintText: 'Enter your Email'),
              ),
              SizedBox(
                height: 8.0,
              ),
              TextField(
                keyboardType: TextInputType.emailAddress,
                textAlign: TextAlign.center,
                obscureText: true,
                onChanged: (value) {
                  password = value;
                },
                decoration:kTextFieldDecoration.copyWith(hintText: 'Enter your Password'),
              ),
              SizedBox(
                height: 24.0,
              ),
              RoundedButton(
                color: mainbg2,
                btntitle: 'Login',
                onpressed: () async {
                  try {
                    final user = await _auth.signInWithEmailAndPassword(email: email, password: password);
        
                    if (user != null) {
                      Navigator.pushNamed(context, ExistUser.id);
                    } else {
                      Navigator.pushNamed(context, FailedPage.id);
                    }
                  } catch (e) {
                    print(e);
                    Navigator.pushNamed(context, FailedPage.id);
                  }
                },
                txtcolor: Colors.white,
              ),
        
              SizedBox(
                height: 30,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
        
                    child: TextButton(
                        onPressed: () async {
                          bool success = await AuthService().signInWithGoogle();
                          if (success) {
                            Navigator.pushNamed(context, ExistUser.id);
                          } else {
                            Navigator.pushNamed(context, FailedPage.id);
                          }
                        },
                        child: Image.asset('assets/lottie/googlelogo.jpg',height: 40,)),
                  ),
                  SizedBox(
                    width: 70,
                  ),
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
        
                    child: TextButton(onPressed: (){

                      Navigator.pushNamed(context, MyPhone.id);
        
                    }, child: Image.asset('assets/lottie/phonelogo.png',height: 40,)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}