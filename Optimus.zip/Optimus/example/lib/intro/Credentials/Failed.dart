import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:optimus/sections/constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class FailedPage extends StatefulWidget {

  static const String id='failedpage';

  const FailedPage({super.key});

  @override
  State<FailedPage> createState() => _FailedPageState();
}
class _FailedPageState extends State<FailedPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: secondSuggestionBoxColor,
      body: Expanded(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Lottie.asset('assets/lottie/failed.json',height: 350),
            SizedBox(
              width: 20,
            ),
            DefaultTextStyle(
              style: const TextStyle(
                fontSize: 45,
                color: Colors.red,
                shadows: [
                  Shadow(
                    blurRadius: 7.0,
                    color: Colors.red,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
              child: Center(
                child: AnimatedTextKit(
                  repeatForever: true,
                  animatedTexts: [
                    FlickerAnimatedText('Login Failed'),
                  ],
                  onTap: () {
                    print("Tap Event");
                  },
                ),
              ),
            ),

            SizedBox(
              width: 20,
            ),


          ],
        ),
      ),

    );
  }

}