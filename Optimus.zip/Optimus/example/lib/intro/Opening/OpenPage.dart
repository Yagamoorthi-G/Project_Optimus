import 'package:optimus/intro/Credentials/Welcome.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class OpenPage extends StatefulWidget {

  static const String id = "Openpage";

  const OpenPage({Key? key}) : super(key: key);

  @override
  State<OpenPage> createState() => _OpenPageState();
}

class _OpenPageState extends State<OpenPage> {
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    // Simulate a 3-second loading time
    Future.delayed(Duration(seconds: 5), () {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
        // Navigate to the MyHomePage after loading
        Navigator.pushNamed(context, WelcomeScreen.id);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? Lottie.asset('assets/lottie/Loading.json',height: 1000)
        : WelcomeScreen();
  }
}




