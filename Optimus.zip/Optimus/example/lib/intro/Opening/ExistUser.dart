import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:optimus/HomePage/home_screen.dart';
import 'package:optimus/intro/Credentials/RoundedButton.dart';
import 'package:optimus/onBoardingScreen/onboarding_screen.dart';
import 'package:optimus/sections/Personalassist.dart';
import 'package:optimus/sections/text_to_image/home_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../sections/constants.dart';

class ExistUser extends StatefulWidget {

  static const String id='ExistUser';

  const ExistUser({super.key});

  @override
  State<ExistUser> createState() => _ExistUserState();
}

final _auth = FirebaseAuth.instance;
late User loggedInUser;
late String CurrentUser;



void getCurrentUser()
{
  try {
    final user = _auth.currentUser!;
    if (user != null) {
      loggedInUser = user;
      CurrentUser = loggedInUser.email!;
    }
  }
  catch(e){
    print(e);
  }
}

class _ExistUserState extends State<ExistUser> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentUser();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: secondSuggestionBoxColor,
        body: Expanded(
        child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            height: 100,
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset('assets/lottie/ExistUser.json',height: 200),
          ],
        ),
          SizedBox(
            height: 100,
          ),
          AnimatedDefaultTextStyle(
            duration: Duration(seconds: 10),
            style: TextStyle(
              fontSize: 24.0,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 2.0,
            ),
            child: Text('Hey! $CurrentUser Welcome Back'),
          ),

          SizedBox(
            height: 100,
          ),
          RoundedButton(color: mainbg2, btntitle: 'Lets Go', onpressed: (){
            Navigator.pushNamed(context, HomeScreen.id);

          }, txtcolor: Colors.white,),


    ],
    ),
    ),
    );
  }
}
