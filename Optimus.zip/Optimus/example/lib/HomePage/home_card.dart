import 'package:optimus/HomePage/home_type.dart';
import 'package:optimus/sections/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';

class HomeCard extends StatelessWidget {

  final HomeType homeType;
  const HomeCard({super.key, required this.homeType});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      margin: const EdgeInsets.only(bottom: 18.0),
      shape: const RoundedRectangleBorder( borderRadius: BorderRadius.all(Radius.circular(28.0),),),
      child: homeType.alignLeft ?
      TextButton(
        onPressed: () {
          String routeName = homeType.changePage;
          Navigator.pushNamed(context, routeName);
        },
        child: Row(
          children: [
            Lottie.asset('assets/homescreen/${homeType.lottieIcon}',width: 135, height: 115),
            const Spacer(flex: 2,),
            Text(
              homeType.cardTitle,
              style:  homeCardTitleTextStyle,
            ).animate(onPlay: (controller) => controller.repeat(reverse: true)).slide().shader()
                // .animate(onPlay: (controller) => controller.repeat(reverse: true))
                // .tint().slide()
                // .shimmer(duration: 3000.milliseconds, color: Colors.orange)
            ,
            const Spacer(),
          ],
        ),
      )
      :
       TextButton(
         onPressed: () {
           String routeName = homeType.changePage;
           Navigator.pushNamed(context, routeName);
         },
         child: Row(
            children: [
           Text(homeType.cardTitle,
               style: homeCardTitleTextStyle,
          ).animate(onPlay: (controller) => controller.repeat(reverse: true)).slide().shader()
             // .animate(onPlay: (controller) => controller.repeat(reverse: true))
             // .tint().slide().shader()
             // .shimmer(duration: 2000.milliseconds, color: Colors.orange)
              ,
              const Spacer(flex: 2,),
              Lottie.asset('assets/homescreen/${homeType.lottieIcon}', width: 135, height: 115),
          const Spacer(),
          ],
         ),
       ),
    );
  }
}
