import 'package:optimus/language_translator/translator.dart';
import 'package:optimus/sections/Personalassist.dart';
import 'package:optimus/sections/text_and_image.dart';
import 'package:optimus/sections/text_only.dart';
import 'package:optimus/sections/text_to_image/home_screen.dart';


enum HomeType {
  // ignore: constant_identifier_names
  card1, card2, card3, card4,card5
}
//overriding the above method

extension MyHomeType on HomeType {
  //GIVING THE "NAMES" TO CARD IN HOMEPAGE
  String get cardTitle => switch(this) {
    HomeType.card1 => 'Personal Assistant',
    HomeType.card2 => 'Image to Text',
    HomeType.card3 => 'Text to Story ',
    HomeType.card4 => 'Text to Image',
    HomeType.card5 => 'Language Translator',
  };
  //GIVING THE "LOTTIE IMAGE" TO CARD IN HOMEPAGE
  String get lottieIcon => switch(this) {
    HomeType.card1 => 'home0.json',
    HomeType.card2 => 'home02.json',
    HomeType.card3 => 'home03.json',
    HomeType.card4 => 'home04.json',
    HomeType.card5 => 'home05.json',
  };

  //HOMEPAGE ICON AND TEXT ALIGNMENT left/right
  bool get alignLeft => switch(this) {
    HomeType.card1 => false,
    HomeType.card2 => true,
    HomeType.card3 => false,
    HomeType.card4 => true,
    HomeType.card5 => false,
  };

  get changePage => switch(this){
    HomeType.card1 =>  MyHomePage.id,
    HomeType.card2 => SectionTextAndImageInput.id,
    HomeType.card3 => SectionTextInput.id,
    HomeType.card4 => HomePage.id,
    HomeType.card5 => TranslatorPage.id,
  };

}

