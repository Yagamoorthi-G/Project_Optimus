import 'package:optimus/HomePage/home_card.dart';
import 'package:optimus/HomePage/home_type.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class HomeScreen extends StatefulWidget {

  static const String id = 'HomeScreen';

  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  ThemeMode currentThemeMode = ThemeMode.dark;
  void toggleTheme() {
    setState(() {
      switch(currentThemeMode) {
        case ThemeMode.light:
          currentThemeMode = ThemeMode.dark;
          break;
        case ThemeMode.dark:
          currentThemeMode = ThemeMode.light;
          break;
        default:
          currentThemeMode = ThemeMode.system;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        elevation: 18.0,
        centerTitle: true,
        title:  Row(
          children: [
            Expanded(
              child: Text(
                'OPTIMUS',
                style: TextStyle(
                  fontSize: 20.0,fontWeight: FontWeight.bold,
                  fontFamily: GoogleFonts.poppins().fontFamily,
                ),
              )
                  .animate(onPlay: (controller) => controller.repeat(reverse: true))
                  .tint()
                  .shimmer(duration: 2000.milliseconds),
            ),

            Lottie.asset('assets/homescreen/logo_welcome.json', height: 50.0, width: 52.0),
          ],
        ),
        actions: [
          IconButton(
            padding: const EdgeInsets.only(right: 24.0, left: 12.0),
            onPressed: () {
              toggleTheme();
              },
            icon:  Icon(
                currentThemeMode == ThemeMode.light ? Icons.light_mode : Icons.dark_mode
              //  Icons.brightness_6_outlined,
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
        children: HomeType.values.map((e) => HomeCard(homeType: e,)).toList(),
      ),
    );
  }
}
